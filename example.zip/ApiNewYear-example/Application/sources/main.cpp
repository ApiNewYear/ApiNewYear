/*
 * main.cpp
 *
 * Project : 	ApiNewYear
 * Created on:  Jan 2, 2015
 * Author: 	    ApiNewYear Team <zia.apinewyear@gmail.com>
 */

#include <cstdlib>
#include <iostream>

int main(void) {
	std::cout << "Hello !" << std::endl;
	return (EXIT_SUCCESS);
}
